#pragma once
#include "pch.h"

using namespace std;
//����(Insertion)

//����(Deletion)

//Ž��(Search)

//��ȸ(Access)

//���� ��ȯ(Size)

template<typename T>
class CList
{
	class CNode
	{
		T m_Data;
		CNode* m_pNext;

	public:
		CNode() :m_pNext(nullptr)
		{
			memset(&m_Data, 0, sizeof(m_Data));
		}
		CNode(T _Data) : m_Data(_Data), m_pNext(nullptr)
		{

		}
	public:
		inline T& Get_Data()
		{
			return m_Data;
		}
		inline void Set_Data(T _Data)
		{
			m_Data = _Data;
		}
		inline CNode* Get_Next()
		{
			return m_pNext;
		}
		inline void Set_Next(CNode* _pNext)
		{
			m_pNext = _pNext;
		}
	};

	CNode m_DummyNode;
	int m_iCount;
	CNode* m_pBefore;
	CNode* m_pCurrent;
	//CNode* m_pFront;
	//CNode* m_pRear;

public:
	CList();
	~CList();
	
	void Release();
public:
	void Initialize();

	void Insert(T _Data);

	void PrintAll();

	void Remove();

	inline int Get_Count()
	{
		return m_iCount;
	}

	CNode& Get_CurrentNode()
	{
		if (m_pCurrent)
		{
			return *m_pCurrent;
		}
		else
		{
			if (m_DummyNode.Get_Next())
			{
				m_pCurrent = m_DummyNode.Get_Next();
				return *m_pCurrent;
			}
		}
	}

	CNode& Next()
	{
		if (!m_pCurrent)
		{
			m_pCurrent = m_DummyNode.Get_Next();
			return *m_pCurrent;
		}

		m_pBefore = m_pCurrent;
		m_pCurrent = m_pCurrent->Get_Next();

		return *m_pCurrent;
	}

};

template<typename T>
inline CList<T>::CList()
	:m_iCount(0), m_pBefore(nullptr), m_pCurrent(nullptr)
{
	memset(&m_DummyNode, 0, sizeof(CNode));
}

template<typename T>
inline CList<T>::~CList()
{
	Release();
}

template<typename T>
void CList<T>::Release()
{
	m_pBefore = &m_DummyNode;
	m_pCurrent = m_DummyNode.Get_Next();

	while (m_iCount > 0)
	{
		Remove();
	}
}

template<typename T>
void CList<T>::Initialize()
{
	m_pBefore = &m_DummyNode;
}

template<typename T>
inline void CList<T>::Insert(T _Data)
{
	CNode* pNewNode = new CNode(_Data);
	
	if (pNewNode)
	{
		pNewNode->Set_Next(m_DummyNode.Get_Next());
		m_DummyNode.Set_Next(pNewNode);

		++m_iCount;
	}


	/*if (m_pFront == nullptr)
	{
		m_pFront = pNewNode;
		m_pRear = pNewNode;
		return;
	}

	m_pRear->Set_Next(pNewNode);
	m_pRear = pNewNode;*/
}

template<typename T>
inline void CList<T>::PrintAll()
{
	if (m_DummyNode.Get_Next() == nullptr)
	{
		cout << "����Ʈ�� �����." << endl;
		return;
	}

	//cout << m_pFront->Get_Data() << endl;

	CNode* pNext = &m_DummyNode;

	while (pNext = pNext->Get_Next())
	{
		cout << pNext->Get_Data() << endl;
	}

}

template<typename T>
inline void CList<T>::Remove()
{
	CNode* Temp = m_pCurrent;

	m_pBefore->Set_Next(m_pCurrent->Get_Next());
	m_pCurrent = m_pCurrent->Get_Next();

	--m_iCount;

	delete Temp;
}
