//�迭 ����Ʈ��
//��ȸ
//������ ���ĺ� ������ �־ ������ ��Ű����

#include<iostream>

using namespace std;

const int iTreeSize = 64;

class ArrayBTree
{
public:
	ArrayBTree();
	~ArrayBTree();
	void Insert(char _cData);
	void Delete(char _cData);
	void PrintAll();
	void PreOderPrint(int iIndex = 1);
	void InOderPrint(int iIndex = 1);
	void PostOrderPrint(int iIndex = 1);
	char* Root();
private:
	char cTree[iTreeSize] = {};
	//����
	//����
};

int main()
{
	ArrayBTree ArrayBTree;

	for (char i = 'A'; i < 'Z' + 1; ++i)
	{
		ArrayBTree.Insert(i);
	}

	//ArrayBTree.PrintAll();
	cout << "���� ��ȸ" << endl;
	ArrayBTree.PreOderPrint();
	cout << endl;

	cout << "���� ��ȸ" << endl;
	ArrayBTree.InOderPrint();
	cout << endl;

	cout << "���� ��ȸ" << endl;
	ArrayBTree.PostOrderPrint();
	cout << endl;


}

ArrayBTree::ArrayBTree()
{
}

ArrayBTree::~ArrayBTree()
{
}

void ArrayBTree::Insert(char _cData)
{
	for (int i = 0; i < iTreeSize; ++i)
	{
		if (cTree[i + 1] == '\0')
		{
			cTree[i + 1] = _cData;
			return;
		}
	}
	
	cout << "Ʈ���� ���� á���ϴ�." << endl;
}

void ArrayBTree::Delete(char _cData)
{
}

void ArrayBTree::PrintAll()
{
	for (int i = 0; i < iTreeSize - 1; ++i)
	{
		if (cTree[i + 1] == '\0')
		{
			return;
		}

		cout << cTree[i + 1] << endl;
	}
}

void ArrayBTree::PreOderPrint(int iIndex)
{
	if (*(Root() + iIndex) == '\0')
	{
		return;
	}

	cout << *(Root() + iIndex);
	PreOderPrint(iIndex * 2);
	PreOderPrint(iIndex * 2 + 1);
}

void ArrayBTree::InOderPrint(int iIndex)
{
	if (*(Root() + 2 * iIndex) == '\0')
	{
		cout << *(Root() + iIndex);
		return;
	}

	InOderPrint(iIndex * 2);
	cout << *(Root() + iIndex);
	InOderPrint(iIndex * 2 + 1);


}

void ArrayBTree::PostOrderPrint(int iIndex)
{
	if (*(Root() + 2 * iIndex) == '\0')
	{
		cout << *(Root() + iIndex);
		return;
	}

	PostOrderPrint(iIndex * 2);
	PostOrderPrint(iIndex * 2 + 1);
	cout << *(Root() + iIndex);
}

char* ArrayBTree::Root()
{
	return cTree;
}

