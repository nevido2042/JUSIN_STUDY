#include "pch.h"
#include "CScene.h"

CScene::CScene()
{
}

CScene::~CScene()
{
}
