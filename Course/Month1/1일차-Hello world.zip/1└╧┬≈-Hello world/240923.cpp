#include <iostream>

using namespace std;

int main()
{
	cout << "�ѿ���" << endl;

	return 0;
}

// soen.kr