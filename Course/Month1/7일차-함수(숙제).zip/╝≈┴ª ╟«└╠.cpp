﻿#include <iostream>

using namespace std;

#pragma region 구구단

// int main()
// {
// 	/*int		i(2), j(1);
// 
// 	while (10 > i)
// 	{
// 		cout << i << " * " << j << " = " << i * j << endl;
// 		++j;
// 
// 		if (10 > j)
// 		{
// 			++i;
// 			j = 1;
// 			cout << "===========================" << endl;
// 		}
// 	}*/
// 
// 	/*for (int i = 2; i < 10; ++i)
// 	{
// 		for (int j = 1; j < 10; ++j)
// 		{
// 			cout << i << " * " << j << " = " << i * j << endl;
// 		}
// 
// 		cout << "===========================" << endl;
// 	}*/
// 
// 	// int		iDan(0), iGob(0);
// 	// 
// 	// cout << "단을 입력하세요 : ";
// 	// cin >> iDan;
// 	// 
// 	// cout << "곱을 입력하세요 : ";
// 	// cin >> iGob;
// 	// 
// 	// for (int i = 2; i <= iDan; ++i)
// 	// {
// 	// 	for (int j = 1; j <= iGob; ++j)
// 	// 	{
// 	// 		cout << i << " * " << j << " = " << i * j << endl;
// 	// 	}
// 	// 
// 	// 	cout << "===========================" << endl;
// 	// }
// 	 
// 	return 0;
// } 


#pragma endregion

#pragma region 별찍기

// int main()
// {
// 	for (int i = 0; i < 5; ++i)
// 	{
// 		for (int j = 0; j < 5; ++j)
// 		{
// 			if(i >= j)
// 				cout << " * " << '\t';
// 			else
// 				cout << " " << '\t';
// 		}
// 
// 		cout << endl;
// 	}
// 
// 	cout << "==================================" << endl;
// 
// 	for (int i = 0; i < 5; ++i)
// 	{
// 		for (int j = 0; j < 5; ++j)
// 		{
// 			if (i <= j)
// 				cout << " * " << '\t';
// 			else
// 				cout << " " << '\t';
// 		}
// 
// 		cout << endl;
// 	}
// 
// 	cout << "==================================" << endl;
// 
// 	for (int i = 0; i < 5; ++i)
// 	{
// 		for (int j = 0; j < 5; ++j)
// 		{
// 			if (4 <= i + j)
// 				cout << " * " << '\t';
// 			else
// 				cout << " " << '\t';
// 		}
// 
// 		cout << endl;
// 	}
// 	cout << "==================================" << endl;
// 
// 	for (int i = 0; i < 5; ++i)
// 	{
// 		for (int j = 0; j < 5; ++j)
// 		{
// 			if (4 >= i + j)
// 				cout << " * " << '\t';
// 			else
// 				cout << " " << '\t';
// 		}
// 
// 		cout << endl;
// 	}
// 
// 
// 	return 0;
// }

#pragma endregion

/*

*
**
***
****
*****

*/