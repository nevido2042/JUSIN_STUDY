#include <iostream>
#include <string.h>

using namespace std;

enum MAIN_MENU_SELECT { GAME_START = 1, GAME_QUIT_M };
enum CLASS_SELECT { WARRIOR = 1, MAGICION, ROGUE, GAME_QUIT_C };
enum TASK_SELECT { HUNT = 1, GAME_QUIT_T };
enum DUNGEON_SELECT { EASY = 1, NORMAL, HARD, GO_TO_TASK_SELECT };
enum BATTLE_TASK_SELECT { ATTACK = 1, RUNAWAY };

typedef struct tagClass
{
	char szName[32];
	int HP;
	int Damage;
}CLASS;

CLASS gWarrior = { "����", 9 , 1 };
CLASS gMagicion = { "������", 5, 5 };
CLASS gRogue = { "����", 7, 3 };

CLASS gMyClass;

CLASS gEasyGoblin{ "�ʱ� ������", 4,1 };
CLASS gNormalGoblin{ "�߱� ������", 5,2 };
CLASS gHardGoblin{ "���� ������", 6,3 };

int Main_Menu();
int Select_Class();
int Select_Task();
int Select_Dungeon();
void Print_MyClass();
void Print_Class(CLASS _Class);
void Start_Battle(CLASS _Monster);
int Select_Battle_Task(CLASS* _pMonster, bool* _pIsBattle);

int main()
{
	while (true)
	{
		if (Main_Menu() == GAME_QUIT_M)
		{
			return 0;
		}

		if (Select_Class() == GAME_QUIT_C)
		{
			return 0;
		}
		
		if (Select_Task() == GAME_QUIT_T)
		{
			return  0;
		}
	}
}

int Main_Menu()
{	
	system("cls");
	cout << "[���� �޴�]" << endl;
	cout << "1. ���� ����" << endl;
	cout << "2. ���� ����" << endl;
	cout << endl;
	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case GAME_START:
		cout << "���� ����" << endl;
		break;

	case GAME_QUIT_M:
		return GAME_QUIT_M;

	default:
		cout << "�߸��� �Է� �Դϴ�." << endl;
		//system("pause");
		return Main_Menu();
	}

	return 0;
}

int Select_Class()
{
	system("cls");
	cout << "[Ŭ���� ����]" << endl;
	cout << "1.����" << endl;
	cout << "2.������" << endl;
	cout << "3.����" << endl;
	cout << "4.���� ����" << endl;
	cout << endl;
	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case WARRIOR:
		gMyClass = gWarrior;
		break;

	case MAGICION:
		gMyClass = gMagicion;

		break;

	case ROGUE:
		gMyClass = gRogue;
		break;

	case GAME_QUIT_C:
		return GAME_QUIT_C;

	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		//system("pause");
		return Select_Class();
	}

	return 0;
}

int Select_Task()
{
	system("cls");
	Print_MyClass();
	cout << endl;

	cout << "[�� �� ����]" << endl;
	cout << "1.���" << endl;
	cout << "2.���� ����" << endl;
	cout << endl;

	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case HUNT:
		if (Select_Dungeon() == GAME_QUIT_T)
		{
			return GAME_QUIT_T;
		}
		break;
	case GAME_QUIT_T:
		return GAME_QUIT_T;
	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		return Select_Task();
	}

	return 0;
}

int Select_Dungeon()
{
	system("cls");
	Print_MyClass();
	cout << endl;

	cout << "[���� ���̵� ����]" << endl;
	cout << "1.�ʱ�" << endl;
	cout << "2.�߱�" << endl;
	cout << "3.����" << endl;
	cout << "4.[�� �� ����]���� ���ư���" << endl;
	cout << endl;

	int iSelect(0);
	cout << "�Է�: ";
	cin >> iSelect;
	switch (iSelect)
	{
	case EASY:
		//cout << "Easy" << endl;
		Start_Battle(gEasyGoblin);
		break;
	case NORMAL:
		//cout << "Normal" << endl;
		Start_Battle(gNormalGoblin);
		break;
	case HARD:
		//cout << "Hard" << endl;
		Start_Battle(gHardGoblin);

		break;
	case GO_TO_TASK_SELECT:
		return Select_Task();
	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		return Select_Dungeon();
	}

	return 0;
}

void Print_MyClass()
{
	//Ŭ���� �̸�, hp, ���ݷ� ���
	cout << "�̸�: "<< gMyClass.szName << endl;
	cout << "ü��: ";// << _Class.HP << endl;
	for (int i = 0; i < gMyClass.HP; ++i)
	{
		cout << "��";
	}
	cout << endl;
	cout << "���ݷ�: ";// << gMyClass.Damage << endl;
	for (int i = 0; i < gMyClass.Damage; ++i)
	{
		cout << "��";
	}
	cout << endl;
}

void Print_Class(CLASS _Class)
{
	cout << "�̸�: " << _Class.szName << endl;
	
	cout << "ü��: ";// << _Class.HP << endl;
	for (int i = 0; i < _Class.HP; ++i)
	{
		cout << "��";
	}
	cout << endl;

	cout << "���ݷ�: ";// << gMyClass.Damage << endl;
	for (int i = 0; i < _Class.Damage; ++i)
	{
		cout << "��";
	}
	cout << endl;
}

void Start_Battle(CLASS _Monster)
{
	bool bIsBattle = true;
	while (bIsBattle)
	{
		system("cls");
		Print_MyClass();
		cout << "------------------" << endl;
		cout << "------------------" << endl;
		Print_Class(_Monster);
		cout << endl;

		Select_Battle_Task(&_Monster, &bIsBattle);
	}
	//cout << "���� ����" << endl;
	//system("pause");
}

int Select_Battle_Task(CLASS* _pMonster, bool* _pIsBattle)
{
	cout <<'['<< gMyClass.szName << "��(��) ������ �ұ�?" << ']'<< endl;
	cout << "1.����" << endl;
	cout << "2.����" << endl;
	cout << endl;

	int iSelect(0);
	cout << "�Է�:";
	cin >> iSelect;

	switch (iSelect)
	{
	case ATTACK:
		_pMonster->HP -= gMyClass.Damage;
		gMyClass.HP -= _pMonster->Damage;

		if (0 >= _pMonster->HP || 0 >= gMyClass.HP)
		{
			*_pIsBattle = false;

			system("cls");
			Print_MyClass();
			cout << "------------------" << endl;
			cout << "------------------" << endl;
			Print_Class(*_pMonster);
			cout << endl;

			if (0 >= _pMonster->HP)
			{
				cout << "�¸�" << endl;
				system("pause");
				return Select_Task();
			}

			if (0 >= gMyClass.HP)
			{
				cout << "�й�" << endl;
				system("pause");
			}
		}
		break;

	case RUNAWAY:
		*_pIsBattle = false;
		return Select_Task();

	default:
		cout << endl;
		cout << "�߸��� �Է��Դϴ�." << endl;
		cout << endl;

		system("cls");
		Print_MyClass();
		cout << "------------------" << endl;
		cout << "------------------" << endl;
		Print_Class(*_pMonster);
		cout << endl;

		return Select_Battle_Task(_pMonster, _pIsBattle);
	}

	return 0;
}
