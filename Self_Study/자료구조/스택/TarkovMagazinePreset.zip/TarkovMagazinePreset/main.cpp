#include<iostream>

using namespace std;

class CStack
{
public:
	CStack(int _iSize)
	{
		pAllocPoint = new char[_iSize];
		pTop = pAllocPoint;
		iSize = _iSize;
	}

	~CStack()
	{
		delete[] pAllocPoint;
	}

	void Push(char _cData)
	{
		*pTop = _cData;
		++pTop;
	}
	char Pop()
	{
		--pTop;
		return *pTop;
	}
	void PrintAll()
	{
		char* pPeek = pTop;
		for (int i = 0; i < iSize; i++)
		{
			pPeek--;
			cout << "| " << *pPeek << " |" << endl;
		}
	}

private:
	char* pAllocPoint = nullptr;
	char* pTop = nullptr;
	int iSize = 0;
};

int main()
{
	cout << "Magazine Preset" << endl;
	cout << endl;
	cout << "Ÿ�������� źâ ������ �ý��� ����" << endl;
	cout << endl;
	cout << "Start: źâ ���� ���� �־�� �� ź" << endl;
	cout << "Loop: Start�� End ���� �ݺ��� ź" << endl;
	cout << "End: źâ ���� �Ʒ� �־�� �� ź" << endl;
	cout << endl;

	char cStart(0);
	char cLoop[3] = { 0, };
	char cEnd(0);
	int iMagazineSize(30);

	cout << "Start : ";
	cin >> cStart;

	cout << "Loop1 : ";
	cin >> cLoop[0];
	cout << "Loop2 : ";
	cin >> cLoop[1];
	cout << "Loop3 : ";
	cin >> cLoop[2];

	cout << "End : ";
	cin >> cEnd;

	cout << "Magazine Size : ";
	cin >> iMagazineSize;

	cout << "==============" << endl;

	//���� ���� �� ź �ֱ�
	CStack Stack(iMagazineSize);

	Stack.Push(cEnd);

	//loop 0 1 2 0 1 2 0 1 2
	//210
	//10
	//0

	int iRemain = (iMagazineSize - 2) % 3;
	for (int i = iRemain - 1; i >= 0; i--)
	{
		Stack.Push(cLoop[i]);
	}
	
	int iIdx(2);
	for (int i = 0; i < iMagazineSize - 2 - iRemain; i++)
	{
		Stack.Push(cLoop[iIdx]);
		iIdx--;
		if (iIdx < 0)
		{
			iIdx = 2;
		}
	}

	Stack.Push(cStart);

	cout << "źâ �� ź ���� ��Ȳ" << endl;

	Stack.PrintAll();

	cout << "==============" << endl;

	//ź �߻�
	cout << "Fire!" << endl;
	for (int i = 0; i < iMagazineSize; i++)
	{
		cout << Stack.Pop() << endl;
	}

	return 0;
}