#include <iostream>
#include <string.h>

using namespace std;

enum MAIN_MENU_SELECT { GAME_START = 1, GAME_QUIT_M };
enum CLASS_SELECT { WARRIOR = 1, MAGICION, ROGUE, GAME_QUIT_C };
enum TASK_SELECT { HUNT = 1, GAME_QUIT_T };
enum DUNGEON_SELECT { EASY = 1, NORMAL, HARD, GO_TO_TASK_SELECT };
enum BATTLE_TASK_SELECT { ATTACK = 1, RUNAWAY };

typedef struct tagClass
{
	char szName[32];
	int HP;
	int Damage;
}CLASS;

CLASS gWarrior = { "����", 9 , 1 };
CLASS gMagicion = { "������", 5, 5 };
CLASS gRogue = { "����", 7, 3 };

//CLASS gMyClass; 
CLASS* g_pMyClass; //���� �Ҵ�

CLASS gEasyGoblin{ "�ʱ� ������", 4, 1 };
CLASS gNormalGoblin{ "�߱� ������", 5, 2 };
CLASS gHardGoblin{ "���� ������", 6, 3 };

CLASS* g_pMonster;

int Main_Menu();
int Select_Class();
int Select_Task();
int Select_Dungeon();
void Print_MyClass();
void Print_Class(CLASS* _Class);
void Start_Battle(CLASS* _Monster);
int Select_Battle_Task(CLASS* _pMonster, bool* _pIsBattle);

int main()
{
	while (true)
	{
		if (Main_Menu() == GAME_QUIT_M)
		{
			break;
		}

		if (Select_Class() == GAME_QUIT_C)
		{
			break;
		}
		
		if (Select_Task() == GAME_QUIT_T)
		{
			break;
		}
	}

	if (g_pMyClass != nullptr)
	{
		delete g_pMyClass;
		g_pMyClass = nullptr;
	}

	if (g_pMonster != nullptr)
	{
		delete g_pMonster;
		g_pMonster = nullptr;
	}

	return 0;
}

int Main_Menu()
{	
	system("cls");
	cout << "[���� �޴�]" << endl;
	cout << "1. ���� ����" << endl;
	cout << "2. ���� ����" << endl;
	cout << endl;
	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case GAME_START:
		cout << "���� ����" << endl;
		break;

	case GAME_QUIT_M:
		return GAME_QUIT_M;

	default:
		cout << "�߸��� �Է� �Դϴ�." << endl;
		//system("pause");
		return Main_Menu();
	}

	return 0;
}

int Select_Class()
{
	system("cls");
	cout << "[Ŭ���� ����]" << endl;
	cout << "1.����" << endl;
	cout << "2.������" << endl;
	cout << "3.����" << endl;
	cout << "4.���� ����" << endl;
	cout << endl;
	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case WARRIOR:
		g_pMyClass = new CLASS;
		*g_pMyClass = gWarrior;
		break;

	case MAGICION:
		g_pMyClass = new CLASS;
		*g_pMyClass = gMagicion;

		break;

	case ROGUE:
		g_pMyClass = new CLASS;
		*g_pMyClass = gRogue;
		break;

	case GAME_QUIT_C:
		return GAME_QUIT_C;

	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		//system("pause");
		return Select_Class();
	}

	return 0;
}

int Select_Task()
{
	system("cls");
	Print_MyClass();
	cout << endl;

	cout << "[�� �� ����]" << endl;
	cout << "1.���" << endl;
	cout << "2.���� ����" << endl;
	cout << endl;

	cout << "�Է�: ";
	int iSelect(0);
	cin >> iSelect;

	switch (iSelect)
	{
	case HUNT:
		if (Select_Dungeon() == GAME_QUIT_T)
		{
			return GAME_QUIT_T;
		}
		break;
	case GAME_QUIT_T:
		return GAME_QUIT_T;
	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		return Select_Task();
	}

	return 0;
}

int Select_Dungeon()
{
	system("cls");
	Print_MyClass();
	cout << endl;

	cout << "[���� ���̵� ����]" << endl;
	cout << "1.�ʱ�" << endl;
	cout << "2.�߱�" << endl;
	cout << "3.����" << endl;
	cout << "4.[�� �� ����]���� ���ư���" << endl;
	cout << endl;

	int iSelect(0);
	cout << "�Է�: ";
	cin >> iSelect;
	switch (iSelect)
	{
	case EASY:
		//cout << "Easy" << endl;
		g_pMonster = new CLASS;
		*g_pMonster = gEasyGoblin;
		Start_Battle(g_pMonster);
		break;
	case NORMAL:
		//cout << "Normal" << endl;
		g_pMonster = new CLASS;
		*g_pMonster = gNormalGoblin;
		Start_Battle(g_pMonster);
		break;
	case HARD:
		//cout << "Hard" << endl;
		g_pMonster = new CLASS;
		*g_pMonster = gHardGoblin;
		Start_Battle(g_pMonster);
		break;
	case GO_TO_TASK_SELECT:
		return Select_Task();
	default:
		cout << "�߸��� �Է��Դϴ�." << endl;
		return Select_Dungeon();
	}

	return GAME_QUIT_T;
}

void Print_MyClass()
{
	//Ŭ���� �̸�, hp, ���ݷ� ���
	cout << "�̸�: "<< g_pMyClass->szName << endl;
	cout << "ü��: ";// << _Class.HP << endl;
	for (int i = 0; i < g_pMyClass->HP; ++i)
	{
		cout << "��";
	}
	cout << endl;
	cout << "���ݷ�: ";// << g_pMyClass->Damage << endl;
	for (int i = 0; i < g_pMyClass->Damage; ++i)
	{
		cout << "��";
	}
	cout << endl;
}

void Print_Class(CLASS* _pClass)
{
	cout << "�̸�: " << _pClass->szName << endl;
	
	cout << "ü��: ";// << _Class.HP << endl;
	for (int i = 0; i < _pClass->HP; ++i)
	{
		cout << "��";
	}
	cout << endl;

	cout << "���ݷ�: ";// << g_pMyClass->Damage << endl;
	for (int i = 0; i < _pClass->Damage; ++i)
	{
		cout << "��";
	}
	cout << endl;
}

void Start_Battle(CLASS* _pMonster)
{
	bool bIsBattle = true;
	while (bIsBattle)
	{
		system("cls");
		Print_MyClass();
		cout << "------------------" << endl;
		cout << "------------------" << endl;
		Print_Class(_pMonster);
		cout << endl;

		Select_Battle_Task(_pMonster, &bIsBattle);
	}
	//cout << "���� ����" << endl;
	//system("pause");
}

int Select_Battle_Task(CLASS* _pMonster, bool* _pIsBattle)
{
	cout <<'['<< g_pMyClass->szName << "��(��) ������ �ұ�?" << ']'<< endl;
	cout << "1.����" << endl;
	cout << "2.����" << endl;
	cout << endl;

	int iSelect(0);
	cout << "�Է�:";
	cin >> iSelect;

	switch (iSelect)
	{
	case ATTACK:
		_pMonster->HP -= g_pMyClass->Damage;
		g_pMyClass->HP -= _pMonster->Damage;

		if (0 >= _pMonster->HP || 0 >= g_pMyClass->HP)
		{
			*_pIsBattle = false;

			system("cls");
			Print_MyClass();
			cout << "------------------" << endl;
			cout << "------------------" << endl;
			Print_Class(_pMonster);
			cout << endl;

			if (0 >= _pMonster->HP)
			{
				cout << "�¸�" << endl;
				system("pause");
			
				delete g_pMonster;
				g_pMonster = nullptr;

				return Select_Task();
			}

			if (0 >= g_pMyClass->HP)
			{
				cout << "�й�" << endl;

				delete g_pMyClass;
				g_pMyClass = nullptr;
				
				system("pause");
			}
		}
		break;

	case RUNAWAY:
		*_pIsBattle = false;
		return Select_Task();

	default:
		cout << endl;
		cout << "�߸��� �Է��Դϴ�." << endl;
		cout << endl;

		system("cls");
		Print_MyClass();
		cout << "------------------" << endl;
		cout << "------------------" << endl;
		Print_Class(_pMonster);
		cout << endl;

		return Select_Battle_Task(_pMonster, _pIsBattle);
	}

	return 0;
}
