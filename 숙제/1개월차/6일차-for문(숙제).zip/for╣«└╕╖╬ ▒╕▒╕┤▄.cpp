#include <iostream>

using namespace std;

int main()
{
	for (int iLeft = 2; iLeft < 10; ++iLeft)
	{
		for (int iRight = 1; iRight < 10; ++iRight)
		{
			cout << iLeft << '*' << iRight << '=' << iLeft * iRight << endl;
		}

		cout << endl;
	}

	system("pause");
}