/*
3. ������ ���� 2�� for���� �̿��Ͽ� �׸��� �ϼ��Ͻÿ�

*
**
***
****
*****

*****
****
***
**
*

	*
   **
  ***
 ****
*****

*****
 ****
  ***
   **
	*

*/

#include <iostream>

using namespace std;

int main()
{
	for (int i = 1; i <= 5; ++i)
	{
		for (int j = 0; j < i; ++j)
		{
			cout << '*';
		}
		cout << endl;
	}

	for (int i = 5; i > 0; --i)
	{
		for (int j = 0; j < i; ++j)
		{
			cout << '*';
		}
		cout << endl;
	}
	//4,1
	//3,2
	//2,3
	//1,4
	//0,5
	for (int i = 4; i >= 0; --i)
	{
		for (int j = 0; j < i; ++j)
		{
			cout << ' ';
		}

		for (int k = 5 - i; k > 0; --k)
		{
			cout << '*';
		}

		cout << endl;
	}

	for (int i = 5; i > 0; --i)
	{
		for (int k = 5 - i; k > 0; --k)
		{
			cout << ' ';
		}

		for (int j = 0; j < i; ++j)
		{
			cout << '*';
		}

		cout << endl;
	}

	system("pause");
}