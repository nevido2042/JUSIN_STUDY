#include <iostream>

using namespace std;

int main()
{
	cout << "��: ";
	int iLeftMax(0);
	cin >> iLeftMax;

	cout << "��: ";
	int iRightMax(0);
	cin >> iRightMax;

	cout << endl;

	for (int iLeft = 2; iLeft < iLeftMax + 1; ++iLeft)
	{
		for (int iRight = 1; iRight < iRightMax + 1; ++iRight)
		{
			cout << iLeft << '*' << iRight << '=' << iLeft * iRight << endl;
		}

		cout << endl;
	}

	system("pause");
}