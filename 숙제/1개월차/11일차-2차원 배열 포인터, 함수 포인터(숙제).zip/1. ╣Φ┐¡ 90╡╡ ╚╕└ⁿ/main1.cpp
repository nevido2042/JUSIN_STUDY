// 1. 2���� �迭�� �̿��Ͽ� ������ ���·� ���� ����� �ؿͶ�
/*
*
1	2	3				7	4	1				9	8	7				3	6	9				1	2	3
4	5	6	-90�� ȸ��>	8	5	2 - 90�� ȸ�� >	6	5	4 - 90�� ȸ�� >	2	5	8 - 90�� ȸ�� >	4	5	6
7	8	9				9	6	3				3	2	1				1	4	7				7	8	9

*/

#include <iostream>

using namespace std;

void RotateRight90(int(*_pArray)[3]);
void Print(int(*_pArray)[3]);
int main()
{
	int iArray[3][3] =
	{
		{1, 2, 3},
		{4, 5, 6},
		{7, 8, 9}
	};

	cout << "�ʱ� ����" << endl;
	Print(iArray);

	cout << "ȸ�� ��: ";

	int iInput(0);
	cin >> iInput;

	cout << endl;

	for (int i = 0; i < iInput; ++i)
	{
		cout << '(' << i + 1 << ')';
		RotateRight90(iArray);
	}

	system("pause");
}

//[0, 0][0, 1][0, 2]
//[1, 0][1, 1][1, 2]
//[2, 0][2, 1][2, 2]
//
//[2, 0][1, 0][0, 0]
//[2, 1][1, 1][0, 1]
//[2, 2][1, 2][0, 2]


void RotateRight90(int(*_pArray)[3])
{
	cout << "������ 90�� ȸ��" << endl;
	int iArray[3][3] = {};

	for (int i = 0; i < 3; ++i)
	{
		for (int j = 2; j >= 0; --j)
		{
			iArray[i][2 - j] = _pArray[j][i];
		}
	}

	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			_pArray[i][j] = iArray[i][j];
		}
	}

	Print(_pArray);

}

void Print(int(*_pArray)[3])
{
	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j)
		{
			cout << _pArray[i][j] << ' ';
		}
		cout << endl;
	}
	cout << endl;
}
