﻿// Class성적프로그램.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.

// 성적표 만들기

// - 성적표 프로그램을 클래스로 만들고 동적 배열을 구현하자
// 1. 입력 2. 모두 출력 3. 검색 4. 종료

// - 입력을 누르면 몇 명을 입력 받을지 묻고 그 숫자만큼 학생들의 성적 정보를 입력 받는다.
// - 모두 출력을 하면 입력된 데이터 모두를 출력한다.
// - 만약, 기존의 데이터가 있는 상태에서 또 다시 입력을 선택하면 몇 명을 추가할 지 묻고 새로 입력받은 추가 데이터를 기존의 데이터와 합친다.

#include "pch.h"

class CStudentInfo
{
    char m_szName[32];
    int m_iKor;
    int m_iEng;
    int m_iMat;
public:
    char* Get_Name();
    int Get_KoreaScore();
    int Get_EnglishScore();
    int Get_MathScore();
public:
    void Set_Name();
    void Set_KoreaScore(int _iScore);
    void Set_EnglishScore(int _iScore);
    void Set_MathScore(int _iScore);
public:
    void Edit_KoreaScore();
    void Edit_EnglishScore();
    void Edit_MathScore();
public:
    void PrintInfo();
};

class CStudentInfoManager
{
    int m_iStudentCount;
    CStudentInfo* m_pArray;
public:
    int Get_StudentCount();
    CStudentInfo* Get_Array();
public:
    void Set_StudentCount(int _iCount);
    void Set_Array(CStudentInfo* _pArray);
    void CopyArray(CStudentInfo* _pNewArray, CStudentInfo* _pOldArray);
    void CreateNewArray(int _iCount);
    void AddStudentInfo();
    void PrintAllInfo();
    void SearchNameToInfo();
};

int main()
{
    CStudentInfoManager* pStudentInfoManager = new CStudentInfoManager();

    int iInput(0);
    
    while (true)
    {
        system("cls");
        cout << "1. 입력 2. 모두 출력 3. 검색 4. 종료" << endl;
        cin >> iInput;

        switch (iInput)
        {
        case 1:
            cout << "입력" << endl;
            cout << "몇 명의 학생의 정보를 입력할 것 인가?" << endl;
            cin >> iInput;
            pStudentInfoManager->CreateNewArray(iInput);

            for (int i = 0; i<iInput; ++i)
            {
                pStudentInfoManager->AddStudentInfo();
                cout << endl;
            }
            break;
        case 2:
            cout << "모두 출력" << endl;
            pStudentInfoManager->PrintAllInfo();
            system("pause");
            break;
        case 3:
            cout << "검색" << endl;
            pStudentInfoManager->SearchNameToInfo();
            system("pause");

            break;
        case 4:
            cout << "종료" << endl;

            return 0;
        default:

            break;
        }
    }

    delete pStudentInfoManager;
    pStudentInfoManager = nullptr;

    return 0;
}

// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.

char* CStudentInfo::Get_Name()
{
    return m_szName;
}

int CStudentInfo::Get_KoreaScore()
{
    return m_iKor;
}

int CStudentInfo::Get_EnglishScore()
{
    return m_iEng;
}

int CStudentInfo::Get_MathScore()
{
    return m_iMat;
}

void CStudentInfo::Set_Name()
{
    char szName[32];
    cout << "이름 입력: ";
    cin >> szName;
    strcpy_s(m_szName, szName);
}

void CStudentInfo::Set_KoreaScore(int _iScore)
{
    m_iKor = _iScore;
}

void CStudentInfo::Set_EnglishScore(int _iScore)
{
    m_iEng = _iScore;
}

void CStudentInfo::Set_MathScore(int _iScore)
{
    m_iMat = _iScore;
}

void CStudentInfo::Edit_KoreaScore()
{
    int iScore;
    cout << "국어 점수 입력: ";
    cin >> iScore;
    Set_KoreaScore(iScore);
}

void CStudentInfo::Edit_EnglishScore()
{
    int iScore;
    cout << "영어 점수 입력: ";
    cin >> iScore;
    Set_EnglishScore(iScore);
}

void CStudentInfo::Edit_MathScore()
{
    int iScore;
    cout << "수학 점수 입력: ";
    cin >> iScore;
    Set_MathScore(iScore);
}

void CStudentInfo::PrintInfo()
{
    cout << "이름: " << Get_Name() << endl;
    cout << "국어: " << Get_KoreaScore() << endl;
    cout << "영어: " << Get_EnglishScore() << endl;
    cout << "수학: " << Get_MathScore() << endl;
}

int CStudentInfoManager::Get_StudentCount()
{
    return m_iStudentCount;
}

CStudentInfo* CStudentInfoManager::Get_Array()
{
    return m_pArray;
}

void CStudentInfoManager::Set_StudentCount(int _iCount)
{
    m_iStudentCount = _iCount;
}

void CStudentInfoManager::Set_Array(CStudentInfo* _pArray)
{
    m_pArray = _pArray;
}

void CStudentInfoManager::CopyArray(CStudentInfo* _pNewArray, CStudentInfo* _pOldArray)
{
    for (int i = 0; i < m_iStudentCount; ++i)
    {
        _pNewArray[i] = _pOldArray[i];
    }
}

void CStudentInfoManager::CreateNewArray(int _iCount)
{
    CStudentInfo* pNewArray = new CStudentInfo[_iCount + Get_StudentCount()];
    CStudentInfo* pOldArray = Get_Array();
    if (pOldArray)
    {
        CopyArray(pNewArray, pOldArray);
        delete pOldArray;
        pOldArray = nullptr;
    }

    Set_Array(pNewArray);
}

void CStudentInfoManager::AddStudentInfo()
{
    CStudentInfo* pEdit = Get_Array();

    CStudentInfo StudentInfo;
    StudentInfo.Set_Name();
    StudentInfo.Edit_KoreaScore();
    StudentInfo.Edit_EnglishScore();
    StudentInfo.Edit_MathScore();

    pEdit[Get_StudentCount()] = StudentInfo;

    Set_StudentCount(Get_StudentCount() + 1);
}

void CStudentInfoManager::PrintAllInfo()
{
    for (int i = 0; i < Get_StudentCount(); ++i)
    {
        Get_Array()[i].PrintInfo();
        cout << endl;
    }
}

void CStudentInfoManager::SearchNameToInfo()
{
    char szName[32] = "";
    cout << "찾으려는 이름을 입력: ";
    cin >> szName;

    for (int i = 0; i < Get_StudentCount(); ++i)
    {
        if (strcmp(Get_Array()[i].Get_Name(), szName) == 0)
        {
            Get_Array()[i].PrintInfo();
            return;
        }
    }
    cout << "이름을 찾을 수 없습니다." << endl;
    return;
}
