﻿#include "pch.h"

struct tagInfo
{
public :
	int		m_iA;

	void	Render()
	{
		cout << m_iA << endl;
		
	}

};

class Obj
{
public:
	Obj();
	Obj(int _iA);

private:
	int		m_iA;

public:
	void	Set_A(int _iA)
	{
		m_iA = _iA;
	}

	int		Get_A()
	{
		return m_iA;
	}


public:
	void	Render();			//클래스 내부 호출

};

Obj::Obj()// 객체 생성 도구 함수
{
	cout << "생성자 호출" << endl;
}

Obj::Obj(int _iA)// 객체 생성 도구 함수
{
	m_iA = _iA;

	cout << "매개 변수가 있는 생성자 호출" << endl;
}

void Obj::Render()
{
	//m_iA = 100;					// 클래스 내부
	cout << m_iA << endl;
}


int main()
{
#pragma region 개론

  // - 절차 지향 프로그래밍 : 함수들이 각자 자신들의 기능을 절차에 의해 호출하는 형식, 동사 격인 '~하다' 중심에 프로그래밍
  // - 객체 지향 프로그래밍 : 프로그래밍을 구성하는 각 객체 간의 의사소통 형식, 주어(객체)에 중점을 둔 프로그래밍
  // 
  // - 객체 : 실 세계를 구성하는 하나의 실체, 데이터(멤버 변수) + 기능(멤버 함수)의 집합
  // - 추상화 : 공통적인 요소를 추출하는 과정 또는 작업

  // C++ = 객체 지향 프로그래밍(O.O.P) + 일반화 프로그래밍(Generic Programming)
  // 
  // 객체 = 인스턴스(실제 메모리에 등록된 상태) + 클래스(자료형)
  // 
  // 클래스(객체) = 멤버 변수 + 멤버 함수
 	
  // 클래스의 속성(은닉화, 캡슐화, 상속성, 다형성) -> 객체의 추상화를 이룸

	#pragma endregion

#pragma region 은닉화

	// 은닉화 : 데이터 보호가 주 목적, 데이터에 접근, 쓰기에 따른 수단을 두는 문법
	// 
	// 1. 접근 제어 지시자를 이용하는 것
	// 2. access method(get, set 함수)를 이용하는 것


	// tagInfo		tInfo = { 100 };	
	// tInfo.Render();

	// Obj		Temp;

	// Obj* pTemp = &Temp;
	// 
	// pTemp->Set_A(400);
	// pTemp->Render();


	//cout << Temp.m_iA << endl;
	//Temp.Set_A(500);
		
	//Temp.Render();			// 외부 호출
	//cout << Temp.Get_A() << endl;

#pragma endregion 은닉화

#pragma region 생성자

	 Obj* pObj = new Obj(100);			// heap 영역에 객체 생성

	//Obj* pObj = (Obj*)malloc(sizeof(Obj));		// malloc은 c언어 시절의 함수여서 객체 생성 과정을 알 수 없다.


	cout << "------------------1----------------" << endl;

	pObj->Set_A(500);

	cout << "------------------2----------------" << endl;

	pObj->Render();

	cout << "------------------3----------------" << endl;

	delete pObj;
	pObj = nullptr;

	// 객체 생성 과정(두 과정은 무조건 순서에 맞게 동작해야함)

	// 1. 메모리 할당(몇 바이트만큼 메모리에 할당)
	// 2. 생성자 호출

	// 객체 생성 시 자동으로 생성되는 함수들
	
	// 1. default 생성자(프로그래머가 명시적으로 구현하지 않을 경우 컴파일러가 스스로 만드는 함수)
	// : 명시적으로 구현된 생성자가 어떤 종류이건 하나라도 존재하면 기본 생성자는 생성 / 호출되지 않음
	// 
	// 2. default 복사 생성자
	// 3. default 대입 연산자
	// 4. default 소멸자



#pragma endregion 생성자

	return 0;
}


// 성적표 만들기

// - 성적표 프로그램을 클래스로 만들고 동적 배열을 구현하자
// 1. 입력 2. 모두 출력 3. 검색 4. 종료

// - 입력을 누르면 몇 명을 입력 받을지 묻고 그 숫자만큼 학생들의 성적 정보를 입력 받는다.
// - 모두 출력을 하면 입력된 데이터 모두를 출력한다.
// - 만약, 기존의 데이터가 있는 상태에서 또 다시 입력을 선택하면 몇 명을 추가할 지 묻고 새로 입력받은 추가 데이터를 기존의 데이터와 합친다.
