﻿// MyString.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//
#include "pch.h"
#include <stdio.h>
#include <iostream>

#define SAFE_DELETE_ARRAY(p) if(p){delete[] p; p = nullptr;}

using namespace std;

// string 클래스를 직접 구현하라
// =, +, == 세 가지 기능을 직접 구현하라

class STRING
{
	const char* m_pString;
public:
	STRING() : m_pString(nullptr)
	{
		
	}
	STRING(const char* _pString) :m_pString(_pString)
	{
		size_t Length = strlen(_pString) + 1;
		m_pString = new char[Length];
		strcpy_s(const_cast<char*>(m_pString), Length, _pString);
	}
	~STRING()
	{
		Release();
	}
public:
	void Release()
	{
		SAFE_DELETE_ARRAY(m_pString);
	}
public:
	void operator= (const char* _pString)
	{
		SAFE_DELETE_ARRAY(m_pString);
		size_t Length = strlen(_pString) + 1;
		m_pString = new char[Length];
		strcpy_s(const_cast<char*>(m_pString), Length, _pString);
	}

	char* operator+(STRING& _rhs)
	{
		size_t Length = strlen(m_pString) + strlen(_rhs.m_pString) + 1;
		char* pTemp = new char[Length];
		strcpy_s(pTemp, Length, m_pString);
		strcat_s(pTemp, Length, _rhs.m_pString);

		return pTemp;
	}

	bool operator==(STRING& _rhs)
	{
		return !strcmp(m_pString, _rhs.m_pString);
	}

	const char* operator()()
	{
		return m_pString;
	}
};

int main()
{
	STRING a;
	a = "def";

	STRING b = "def";

	if (a == b)
	{
		printf("%s\n", "same");
	}

	STRING c = a + b;

	printf("%s\n", a());
	printf("%s\n", b());
	printf("%s\n", c());

	cout << a() << endl;
	cout << b() << endl;
	cout << c() << endl;
}

// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.
