﻿// 241106.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"

class CObj
{
public:
	CObj() {}
	CObj(int _iX, int _iY) : m_iX(_iX), m_iY(_iY) {}

	CObj& operator =(CObj& rhs)
	{
		m_iX = rhs.m_iX;
		m_iY = rhs.m_iY;

		return *this;
	}

	// default 대입 연산자와 복사 생성자를 생성하지 않고 문법에서 제외시킴
	// CObj& operator =(CObj& rhs) = delete;
	// CObj(const CObj& rhs)       = delete;

public:
	void	Render() { cout << m_iX << "\t" << m_iY << endl; }

public:
	CObj	operator +(CObj& rhs)
	{
		CObj	Result(m_iX + rhs.m_iX, m_iY + rhs.m_iY);

		return Result;
	}

	CObj	operator +(int iData)
	{
		CObj	Result(m_iX + iData, m_iY + iData);

		return Result;
	}

	CObj& operator ++()
	{
		m_iX += 1;
		m_iY += 1;

		return *this;
	}

	CObj	operator ++(int)		// 후위 연산을 의미함
	{
		CObj	Result(*this);

		m_iX += 1;
		m_iY += 1;

		return Result;
	}


private:
	int		m_iX;
	int		m_iY;
	//int*	m_p;

};

// 전역 함수
CObj	operator +(int iData, CObj& rhs)
{
	CObj	Result(rhs + iData);

	return Result;
}


int main()
{
	// 연산자 오버로딩 : 함수 오버로딩의 규칙 연산자에 적용하는 문법
	// - 연산자의 좌측 객체 기준으로 동작이 수행
	// - operator 키워드를 이용하여 연산자의 이름을 함수를 생성
	// - 연산자의 고유 기능의 변경은 불가하다.
	
	// 반드시 클래스의 멤버로만 연산자 오버로딩이 가능한 경우
	// '=', '()', '[]', '->'

	//CObj		Obj;

	CObj		Temp(10, 20);

	//++(++Temp);
	//(Temp++)++;

	Temp.Render();

	//CObj		Src(30, 40);
	//Obj = Temp;

	//Obj = Temp + 10;

	//Obj = 10 + Temp;	// 교환 법칙
	//
	//Obj.Render();
	//   
	return 0;
}
